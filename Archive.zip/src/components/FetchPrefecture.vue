<!-- eslint-disable vue/no-mutating-props -->
<!-- eslint-disable vue/no-setup-props-destructure -->
<!-- eslint-disable vue/no-dupe-keys -->
<script setup>
import axios from 'axios'
import { ref, onMounted, defineEmits, defineProps } from 'vue'

const { setAge } = defineProps(['setAge'])
const currId = ref('')
const currName = ref('')
const currisChecked = ref(false)

function sayHello() {
  console.log('Hello')
}

const emit = defineEmits(['addItems', 'removeItems'])

const ACCESS_TOKEN = 'GKVk1oWzexxJz7hrgnivmX20jtuGKMbU1LMx4i16'

const getPrefectures = async (path) => {
  const response = await axios.get(`https://opendata.resas-portal.go.jp/api/v1/${path}`, {
    headers: {
      'X-API-KEY': ACCESS_TOKEN
    }
  })
  return response
}

const prefectures = ref([])
const insertedGraphs = ref([])
const callUP = (setAge) => {
  console.log('I am in callUP')
  console.log(currId.value)
  console.log(setAge)
  return updatePopulation(currId.value, setAge)
}

defineExpose({
  prefectures,
  insertedGraphs,
  sayHello,
  callUP
})

onMounted(async () => {
  fetchPrefectures()
})

const fetchPrefectures = async () => {
  const path = 'prefectures'
  try {
    const response = await getPrefectures(path)
    prefectures.value = response.data.result.map((val) => {
      return {
        id: val['prefCode'],
        name: val['prefName'],
        isChecked: false
      }
    })
  } catch (error) {
    console.error(error.message)
  }
}

const drawChart = async (id, name) => {
  console.log('Im currently in DrawChart, and the id is ' + setAge)
  const path = `population/composition/perYear?prefCode=${id}`
  try {
    const response = await getPrefectures(path)
    const population = response.data.result.data[0].data.map((val) => val['value'])
    emit('addItems', id, name, population)
    prefectures.value[id - 1].isChecked = true
    console.log(prefectures.value[id - 1].isChecked)
  } catch (error) {
    console.error(error.message)
  }
}

const drawChartAge = async (id, name, age) => {
  const path = `population/composition/perYear?prefCode=${id}`
  try {
    const response = await getPrefectures(path)
    const population = response.data.result.data
      .find((item) => item.label === age)
      .data.map((val) => val['value'])
    emit('addItems', id, name, population)
    prefectures.value[id - 1].isChecked = true
    console.log(prefectures.value[id - 1].isChecked)
  } catch (error) {
    console.error(error.message)
  }
}

const updatePopulation = async (id, setAge) => {
  console.log('I am in updatePopulation, and the Age is ' + setAge)
  console.log('I am in updatePopulation, and the id is ' + id)
  const path = `population/composition/perYear?prefCode=${id}`
  try {
    const response = await getPrefectures(path)
    const population = response.data.result.data
      .find((item) => item.label === setAge)
      .data.map((val) => val['value'])
    prefectures.value[id - 1].isChecked = true
    console.log(prefectures.value[id - 1].isChecked)
    if (population !== undefined) {
      console.log('I am in updatePopulation, population is VALID!')
      console.log(setAge)
      deleteChart(id)
      drawChartAge(id, currName.value, setAge)
    }
  } catch (error) {
    console.error(error.message)
  }
}

const deleteChart = (id) => {
  emit('removeItems', id)
  insertedGraphs.value = insertedGraphs.value.filter((item) => item.id !== id)
  prefectures.value[id - 1].isChecked = false
  console.log(setAge)
}

const switchChart = (id, name, isChecked, setAge) => {
  if (isChecked) {
    deleteChart(id)
    currId.value = ''
    currName.value = ''
    currisChecked.value = false
  } else {
    if (setAge === '合計' || setAge === '総人口') {
      console.log('If no place')
      currId.value = id
      currName.value = name
      currisChecked.value = true
      drawChart(id, name)
    } else {
      currId.value = id
      currName.value = name
      currisChecked.value = true
      console.log('Im currently in switchChart, and the age is ' + setAge)
      drawChartAge(id, name, setAge)
    }
  }
}

const isCheckedColor = (isChecked) => {
  if (isChecked) {
    return '#3a0852'
  } else {
    return '#ffffff'
  }
}
</script>

<template>
  <div class="PrefZone">
    <!-- <input v-model.trim="search" type="text" placeholder="県サーチ。。。" /> -->
    <div v-for="prefecture in prefectures" :key="prefecture.id" class="prefecture">
      <label :for="prefecture.id">
        <input
          type="checkbox"
          :id="prefecture.id"
          :checked="prefecture.isChecked"
          @click="
            console.log(setAge),
              switchChart(prefecture.id, prefecture.name, prefecture.isChecked, setAge)
          "
          :style="{ backgroundcolor: isCheckedColor }"
        />
        {{ prefecture.name }}
      </label>
    </div>
  </div>
</template>

<style scoped>
.prefZone {
  display: flex;
  justify-content: space-between;
  margin: 10px auto;
  padding: 10px 10px;
  background-color: #cd2222;
  border-radius: 20px;
  border: #7b3a9b;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

.prefecture {
  margin: 5px;
  padding: 15px;
  background-color: #ffffff;
  color: black;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

.prefecture:checked {
  background-color: #3a0852;
  color: #ffffff;
}

.selection {
  display: flex;
  flex-wrap: nowrap;
  justify-content: space-between;
}

.prefecture:hover {
  background-color: #3a0852;
  color: #ffffff;
}
</style>
